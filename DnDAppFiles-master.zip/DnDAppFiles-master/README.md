# DnDAppFiles

Files for the GM5 and Fight Club apps from Lion's Den

Please do NOT use these files unless you know what you are doing. The files here are a work in progress, and are not guaranteed to work properly when imported.

If you would like files for import in your app, please go to www.tinyurl.com/DnDAppFiles to request an invite to a shared Dropbox folder.

We are not affiliated with Leo or Lion's Den in any way.
